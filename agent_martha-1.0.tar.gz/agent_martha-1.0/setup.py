#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Sep 10 12:32:39 2023

@author: roboteknologies
"""

from setuptools import setup, find_packages

setup(
    name='agent_martha',
    version='1.0',
    author='roboteknologies',
    packages=find_packages(),
)
